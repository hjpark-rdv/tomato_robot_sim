from pathlib import Path
import shutil,json,hashlib,tarfile,subprocess
R=Path('/root/docker_share/mujoko_debugging_data/20260928_164835_start_recovery_d1');D=Path('/root/farmily_tomato/mujoco-benchmark/validation/start_recovery_server');D.mkdir(parents=True,exist_ok=True)
S=R/'execution_scripts';S.mkdir(exist_ok=True)
for name in ['run_start_recovery_server.sh','resume_start_recovery_compat.py','record_recovered_hold.py','render_start_recovery_diagnostics.py','summarize_start_recovery_server.py','package_start_recovery_server.py']:
 shutil.copy2(Path('/tmp')/name,S/name)
L=R/'validation_logs';L.mkdir(exist_ok=True)
for n in ['start_recovery_tests.log','start_recovery_tests_final.log','start_recovery_compat_tests.log','start_recovery_diagnostic_render.log']:
 shutil.copy2(Path('/tmp')/n,L/n)
shutil.copy2(R.with_suffix('.launch.log'),L/'one_command_launch.log')
F=Path('/root/docker_share/mujoko_debugging_data/20260928_164744_start_recovery_d1')
for f in [F.with_suffix('.launch.log'),F/'start_recovery.log']:
 if f.exists():shutil.copy2(f,L/('initial_missing_fcl_'+f.name))
shutil.copy2('/root/farmily_tomato/mujoco-benchmark/START_RECOVERY_SERVER_REPORT_KO.md',R/'START_RECOVERY_SERVER_REPORT_KO.md')
files=[];links=[]
for p in sorted(R.rglob('*')):
 if p.is_symlink():links.append(dict(path=str(p.relative_to(R)),target=str(p.resolve())))
 elif p.is_file():files.append(dict(path=str(p.relative_to(R)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
(R/'artifact_manifest.json').write_text(json.dumps(dict(files=files,external_symlinks=links,training_eligible=False),indent=2))
# Include all regular evidence files and never dereference model/pkl symlinks.
with tarfile.open(D/'server_evidence.tar.gz','w:gz') as t:
 for p in sorted(R.rglob('*')):
  if p.is_file() and not p.is_symlink():t.add(p,arcname=str(p.relative_to(R)),recursive=False)
for name in ['index.html','server_summary.json','new_prefix_hash_comparison.json','video_validation.json','artifact_manifest.json','environment.json']:
 shutil.copy2(R/name,D/name)
for dirname in ['start_pose_comparison','canonical_hold_video','diagnostic_images']:
 (D/dirname).mkdir(exist_ok=True)
 for p in (R/dirname).iterdir():
  if p.suffix in ['.mp4','.png','.json'] and p.is_file():shutil.copy2(p,D/dirname/p.name)
for name in ['compat_recovery/pipeline_summary.json','compat_recovery/effective_plan_results.json','compat_recovery/new_start_physics_results.json','start_recovery/canonical_start.json','start_recovery/start_recovery.json']:
 (D/name).parent.mkdir(exist_ok=True);shutil.copy2(R/name,D/name)
shutil.copytree(L,D/'logs',dirs_exist_ok=True)
(D/'README.md').write_text('''# Start recovery 서버 증거

[서버 보고서](../../START_RECOVERY_SERVER_REPORT_KO.md), [대시보드](index.html).

`server_evidence.tar.gz`에는 모든 질의의 connection result, IK record, prefix command,
환경 audit, source provenance, canonical hold qpos, 실제 MP4, 명목 충돌 이미지,
실행 스크립트와 로그가 들어 있다. 실패한 원본 및 4건의 호환 수정 후 결과를 모두 보존했다.

추출: `tar -xzf server_evidence.tar.gz -C 새_빈_폴더`.
대형 MJB/pkl symlink는 제외했다. 외부 경로는 `artifact_manifest.json:external_symlinks`,
모델 SHA는 `server_summary.json:models` 및 각 provenance를 확인한다.
NAS가 없는 곳에서도 JSON/영상/로그는 확인 가능하지만 물리 재실행은 외부 모델이 필요하다.

최종 결과는 `compat_recovery/effective_plan_results.json`이다.
원본 `d1/new_start_plan_results.json`의 4건 execution_error를 최종 실패로 세지 않는다.
18개 접근 branch는 계획/검사 결과이며 실제 도달 물리가 아니다.
실제 영상은 hold만이고 왼쪽 과거 기록과 오른쪽 새 기록의 출처를 명시했다.
''')
print('archive bytes',(D/'server_evidence.tar.gz').stat().st_size,'files',len(files),'links',len(links))
