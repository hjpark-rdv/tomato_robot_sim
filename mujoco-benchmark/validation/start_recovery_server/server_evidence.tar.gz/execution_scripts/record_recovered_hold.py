import sys,json
from pathlib import Path
import numpy as np
sys.path.insert(0,'/root/farmily_tomato/mujoco-benchmark/scripts')
from materialize_new_start_run import materialize
from initial_configuration_recovery import hold_rows
from robot_engine import RobotEngine
root=Path(Path('/tmp/start_recovery_current_output').read_text().strip())
source=Path('/root/docker_share/mujoko_debugging_data/20260927_stem_obstacle_scene/robot_checks/Tomato_02')
covered=Path('/mnt/nas_rdv_md3/covered_d1_20260928/covered_scene');run=root/'canonical_hold_video/run'
materialize(source,root/'start_recovery/canonical_start.json',run,model=covered/'model.mjb',reference=covered/'reference.json')
q=json.loads((root/'start_recovery/canonical_start.json').read_text())['q'];rows=hold_rows(q,seconds=2.)
dest=run/'candidates/canonical_hold';dest.mkdir(parents=True)
(dest/'trace.json').write_text(json.dumps(rows));(dest/'plan.json').write_text(json.dumps(dict(seconds=2.,diagnostic_only=True,training_eligible=False,hook_success=None,scope='fresh stationary canonical-start hold; no approach/manipulation')))
e=RobotEngine(run/'replay_assets/model.mjb',run/'replay_assets/initial_trace.json',240,reference=run/'replay_assets/reference.json',target='Tomato_02');result=e.rollout(2.,record=True)
np.savez_compressed(run.parent/'states.npz',**result.pop('_arrays'));contacts=result.pop('_contacts');(run.parent/'contacts.json').write_text(json.dumps(contacts));(run.parent/'result.json').write_text(json.dumps(result,indent=2))
from render_contact_diagnostic import render
render(run,run.parent/'states.npz',run.parent/'canonical_hold.mp4',label='canonical start hold ONLY; no manipulation',speed=1,candidate='canonical_hold',highlights={'g410':[0,1,1,1],'neighbor_truss_collision_fruit_p19_t02_g052':[1,0,.5,1]})
