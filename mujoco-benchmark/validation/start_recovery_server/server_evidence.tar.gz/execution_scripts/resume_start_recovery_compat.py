"""Continue only pre-planning compatibility failures through the existing D1 runner."""
import sys,json,copy
from pathlib import Path
sys.path.insert(0,'/root/farmily_tomato/mujoco-benchmark/scripts')
from run_new_start_d1 import run_plans,run_physics
from run_start_recovery_pipeline import summarize
root=Path(Path('/tmp/start_recovery_current_output').read_text().strip());out=root/'compat_recovery';out.mkdir(exist_ok=False)
doc=json.loads((root/'d1/new_start_queries.json').read_text());old=json.loads((root/'d1/new_start_plan_results.json').read_text());retry=[]
for row in old['rows']:
 if row['status']!='execution_error':continue
 error=json.loads(Path(row['connection_result']).read_text())
 if error.get('error')!='ValueError: Local design changed approach; not a matched comparison' or error.get('attempts') or error.get('ik_records'):
  raise ValueError('Not a pre-planning heading compatibility error')
 q=copy.deepcopy(next(q for q in doc['queries'] if q['query_id']==row['query_id']));q['retry_of']=q['output'];q['output']=str(out/'plans'/q['query_id']);q['command'][q['command'].index('--output')+1]=q['output'];retry.append(q)
retry_doc=copy.deepcopy(doc);retry_doc['queries']=retry
(out/'retry_queries.json').write_text(json.dumps(retry_doc,indent=2))
rows=run_plans(retry_doc,out)
replaced={r['query_id']:r for r in rows};merged=[replaced.get(r['query_id'],r) for r in old['rows']]
merged_doc=copy.deepcopy(doc);rq={q['query_id']:q for q in retry}
merged_doc['queries']=[rq.get(q['query_id'],q) for q in doc['queries']]
(out/'effective_queries.json').write_text(json.dumps(merged_doc,indent=2))
plans=dict(rows=merged,reported_queries=len(merged),evaluated_queries=len(merged),whole_paths=sum(bool(r.get('whole_path_passed')) for r in merged),compatibility_retries=len(retry),original_failed_invocations_preserved=True)
(out/'effective_plan_results.json').write_text(json.dumps(plans,indent=2))
trials=run_physics(merged_doc,merged,out,'/root/farmily_tomato/mujoco-benchmark/.recovery-venv/bin/python',max_executions=8,render=True)
start=json.loads((root/'start_recovery/start_recovery.json').read_text());final=summarize(start,plans,dict(trials=trials))
summary=dict(schema='start_recovery_server_completion_v1',original_pipeline=str(root/'pipeline_summary.json'),status='completed_with_server_heading_compatibility_fix',final=final,planning_results=str(out/'effective_plan_results.json'),physics_results=str(out/'new_start_physics_results.json'),unique_design_queries=len(merged),preplanning_error_retries=len(retry),training_eligible=False,hook_success=None,impossible=None)
(out/'pipeline_summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2),flush=True)
