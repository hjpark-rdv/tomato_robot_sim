import json, hashlib, html, collections, shutil, subprocess
from pathlib import Path
import numpy as np
R=Path('/root/docker_share/mujoko_debugging_data/20260928_164835_start_recovery_d1')
def read(p):return json.loads(Path(p).read_text())
def write(p,d):Path(p).write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
rows=read(R/'compat_recovery/effective_plan_results.json')['rows'];canon=read(R/'start_recovery/canonical_start.json');summary=[];prefixes=[];stats=collections.Counter();models=[]
for row in rows:
 p=Path(row['connection_result']);d=read(p);a=d.get('attempts',[])
 compact=dict(query_id=row['query_id'],scene=row['scene'],target=row['target'],design=row['design'],status=row['status'],source_unchanged=d['source_unchanged'],prefix_reused=d['prefix_reused'],whole_path_passed=d['whole_path_passed'],ik_status_counts=dict(collections.Counter(x['status'] for x in d['ik_records'])),goal_collisions=[x['collision'] for x in d['ik_records'] if 'collision' in x],approach_passes=len(d['approach_only_runs']),attempts=a,physics_executed=False)
 summary.append(compact)
 for b in a:
  stats[b['status']]+=1
  if b.get('whole_environment_check'):stats['audit_'+b['whole_environment_check']]+=1
 for f in p.parent.glob('branch_*/prefix_joint_path.json'):
  t=read(f);q=np.array(t['commands'],dtype=np.float64);audit=read(f.parent/'approach_only_audit.json');starts=np.allclose(q[0],canon['q'],rtol=0,atol=1e-8)
  assert starts and audit['passed'] and audit['complete']
  prefixes.append(dict(query_id=row['query_id'],branch=f.parent.name,method=t['method'],samples=len(q),commands_f64_sha256=hashlib.sha256(q.tobytes()).hexdigest(),file_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),canonical_start_matches=bool(starts),audit_passed=audit['passed'],audit_complete=audit['complete'],audit_status=audit['status']))
 for b in a:
  f=p.parent/f"branch_{b['branch_index']:02d}"/'environment_preflight.json'
  if f.exists():
   audit=read(f);b['audit_complete']=audit['complete'];b['audit_error']=audit.get('error');b['last_completed_sample_time_s']=audit.get('last_completed_sample_time_s')
queries=read(R/'compat_recovery/effective_queries.json')
for m in queries['materialized_runs']:
 d=m['provenance'];models.append({k:d[k] for k in ['source_run','destination','selected_model','selected_model_sha256','selected_reference_sha256','planning_model_sha256','source_candidates_sha256','source_initial_trace_sha256','derived_initial_trace_sha256']})
final=dict(schema='start_recovery_server_summary_v1',source_code='30facc9',compatibility_fix='3c11d41',branch='codex/start-recovery-20260928',case='CASE2_LOCAL_MANIPULATION',canonical=canon,unique_queries=len(rows),adapter_invocations=15,pre_IK_compatibility_errors=4,prefix_queries=sum(bool(x['approach_passes']) for x in summary),audited_prefixes=len(prefixes),attempt_counts=dict(stats),whole_paths=sum(x['whole_path_passed'] for x in summary),manipulation_physics_executions=0,physics_budget=8,hold_validation_count=6,additional_recorded_hold_count=1,physics_scope='Only covered-scene initial hold was executed. No D1 manipulation or approach-only physics.',model_scope='Canonical q: dense covered MJB. D1: supplied historical scene models, not dense covered MJB.',models=models,rows=summary,training_eligible=False,hook_success=None,impossible=None)
assert len(summary)==11 and all(x['source_unchanged'] for x in summary) and not any(x['prefix_reused'] for x in summary)
write(R/'server_summary.json',final);write(R/'new_prefix_hash_comparison.json',prefixes)
e=html.escape
trs=[]
for row in summary:
 if not row['attempts']:reason='有効な IK 解未発見' # overwritten with Korean below
 if not row['attempts']:reason='8 IK seed 내 충돌 없는 준비 자세 해 미발견'
 else:
  descriptions=[]
  for a in row['attempts']:
   hit=a.get('first_violation')
   if hit:desc='/'.join(hit['phases'])+': '+hit['environment_geom']
   elif a.get('audit_error'):desc='전체 검사 미완료: '+a['audit_error']
   else:desc='suffix 자기충돌: '+str(a.get('suffix_planner',{}).get('phase'))
   descriptions.append(f"branch {a['branch_index']}: {desc}")
  reason='<br>'.join(e(x) for x in descriptions)
 trs.append(f"<tr><td>{e(row['query_id'])}</td><td>{row['approach_passes']}</td><td>{reason}</td><td>0 / 미실행</td></tr>")
page='''<!doctype html><html lang="ko"><meta charset="utf-8"><title>Start recovery 서버 결과</title><style>body{font:16px/1.6 sans-serif;max-width:1200px;margin:30px auto;padding:0 20px;background:#111827;color:#edf2f7}a{color:#7dd3fc}table{border-collapse:collapse;width:100%}td,th{border:1px solid #526078;padding:8px;text-align:left}video,img{max-width:100%}.warn{background:#45321b;padding:16px}code{overflow-wrap:anywhere}</style><h1>시작 충돌 해결 → D1 11개 비교 완료</h1><p>손목2 −7.2°로 초기 충돌 해소. 28개 시작 자세 검사 / 12개 정적 통과 / 상위6개 hold 검사. 선택 자세는 2초 물리 정상, 로봇 drift 0, 식물 최대 변위 2.968mm.</p><p>6개 질의(2타깃 × 3자세)의 18개 접근 경로 검사 통과. 전체 조작 경로 통과 0, 수확 물리 실행 0. 18개 branch의 suffix는 환경 차단14 / 자기충돌1 / 전체 검사 시간한도 미완료3. 유한 탐색 결과이며 수확 불가능 판정이 아님.</p><div class="warn">범위: dense covered MJB는 시작 자세 검증에 사용. 문서의 D1 실행기는 기존 장면별 MJB를 사용함. 아래 영상은 정지 검증이며 접근·걸림 성공 영상이 아님. training_eligible=false, hook_success=null.</div><h2>실제 저장 qpos: 시작 충돌 전후</h2><p>왼쪽은 과거 원본 시작 자세의 물리 기록, 오른쪽은 이번 canonical 자세의 새 물리 기록. 동일 covered MJB. 충돌체를 보기 위해 배경 시각 메시만 숨김.</p><video controls src="start_pose_comparison/idle_ab.mp4"></video><h2>이번 canonical start: 2초 실제 hold</h2><video controls src="canonical_hold_video/canonical_hold.mp4"></video><h2>검사에서 막힌 자세 (물리 실행 아님)</h2><p>청록: 로봇 충돌체 / 분홍: 금지 장애물. 저장 명령 q를 설정한 기하 진단 이미지.</p><img src="diagnostic_images/q00_nominal_collision.png"><img src="diagnostic_images/q04_nominal_collision.png"><h2>11개 질의 결과</h2><table><tr><th>query</th><th>접근 branch 통과</th><th>병목</th><th>전체 통과 / 물리</th></tr>'''+''.join(trs)+'''</table><h2>증거</h2><p><a href="server_summary.json">최종 집계 JSON</a> · <a href="compat_recovery/pipeline_summary.json">호환 수정 후 완료</a> · <a href="compat_recovery/effective_plan_results.json">11개 계획 결과</a> · <a href="new_prefix_hash_comparison.json">새 접근 명령 해시</a> · <a href="start_recovery/canonical_start.json">선택 시작 자세</a></p><p>원본 one-command 출력과 4건의 pre-IK 오류를 보존했고, 호환 수정 후 해당 4건만 같은 입력·예산으로 이어 실행함. 고유 설계 11개, adapter 호출 15회.</p></html>'''
(R/'index.html').write_text(page)
print(json.dumps({k:v for k,v in final.items() if k in ['unique_queries','prefix_queries','audited_prefixes','attempt_counts','whole_paths']},indent=2))
