import sys,json
from pathlib import Path
sys.path.insert(0,'/root/farmily_tomato/mujoco-benchmark/scripts')
import render_backend
import mujoco as mj
import numpy as np
from PIL import Image,ImageDraw
r=Path(Path('/tmp/start_recovery_current_output').read_text().strip());out=r/'diagnostic_images';out.mkdir(exist_ok=True)
rows=json.loads((r/'d1/new_start_queries.json').read_text())['queries']
for index in [0,4]:
 query=rows[index];base=Path(query['output']);result=json.loads((base/'connection_result.json').read_text());run=Path(query['new_start_run'])
 if index==0:
  rec=next(x for x in result['ik_records'] if x.get('collision',{}).get('kind')=='environment_collision');q=rec['q'];pair=rec['collision']['pair'];caption='IK preparation pose: environment collision (NOT executed)'
 else:
  report=json.loads((base/'branch_00/environment_preflight.json').read_text());hit=report['first_violation'];q=hit['command'];pair=[hit['robot_geom'],hit['environment_geom']];caption='Nominal seat pose: non-target pedicel collision (NOT executed)'
 m=mj.MjModel.from_binary_path(str(run/'replay_assets/model.mjb'));d=mj.MjData(m)
 ref=json.loads((run/'replay_assets/reference.json').read_text());qids=[m.jnt_qposadr[m.joint(n).id] for n in ref['robot_fk']['joint_names']];d.qpos[qids]=q;mj.mj_forward(m,d)
 gids=[m.geom(n).id for n in pair];seg=np.zeros(6);dist=float(mj.mj_geomDistance(m,d,*gids,1.,seg));center=seg.reshape(2,3).mean(axis=0)
 for gid,color in zip(gids,[[0,1,1,1],[1,0,.5,1]]):m.geom_group[gid]=0;m.geom_rgba[gid]=color
 cam=mj.MjvCamera();cam.lookat[:]=center;cam.distance=.35 if index==0 else .13;cam.azimuth=30;cam.elevation=-25
 opt=mj.MjvOption();opt.geomgroup[2]=0
 renderer=mj.Renderer(m,width=800,height=600,max_geom=20000);renderer.update_scene(d,camera=cam,scene_option=opt)
 canvas=Image.new('RGB',(800,670),(20,20,25));canvas.paste(Image.fromarray(renderer.render()),(0,70));draw=ImageDraw.Draw(canvas);draw.text((10,6),caption,fill='white');draw.text((10,26),f'{pair[0]} / {pair[1]} | gap={dist*1000:.6f} mm',fill='yellow');draw.text((10,46),'CYAN robot collider | PINK forbidden environment collider | background visuals hidden',fill='white')
 canvas.save(out/f'q{index:02d}_nominal_collision.png');renderer.close()
 (out/f'q{index:02d}_nominal_collision.json').write_text(json.dumps(dict(query=query['query_id'],run=str(run),q=q,pair=pair,signed_distance_m=dist,physics_executed=False,caption=caption),indent=2))
