#!/bin/bash
set -eu
cd /root/farmily_tomato
task_out="/root/docker_share/mujoko_debugging_data/$(date +%Y%m%d_%H%M%S)_start_recovery_d1"
printf '%s\n' "$task_out" > /tmp/start_recovery_current_output
./mujoco-benchmark/.recovery-venv/bin/python -u mujoco-benchmark/scripts/run_start_recovery_pipeline.py --dense-source-run /root/docker_share/mujoko_debugging_data/20260927_stem_obstacle_scene/robot_checks/Tomato_02 --covered-scene /mnt/nas_rdv_md3/covered_d1_20260928/covered_scene --campaign /root/docker_share/mujoko_debugging_data/20260928_multifamily_server/pilot --side-campaign /root/docker_share/mujoko_debugging_data/20260928_multifamily_server/side_repair --prefix-report /root/farmily_tomato/mujoco-benchmark/validation/multifamily_server/prefix_comparison.json --output "$task_out" --planning-python /root/farmily_tomato/mujoco-benchmark/.recovery-venv/bin/python --native-python /root/farmily_tomato/mujoco-benchmark/.recovery-venv/bin/python --model-cache /mnt/nas_rdv_md3/mujoco_search_cache --render-physics > "$task_out.launch.log" 2>&1
